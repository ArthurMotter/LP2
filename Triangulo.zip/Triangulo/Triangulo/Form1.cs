﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        double valA = 0, valB = 0, valC = 0, resultado = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtbxA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxA.Text, out valA))
            {
                MessageBox.Show("Valor inválido!");
                //txtBx2.Focus();
            }
        }

        private void TxtbxB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxB.Text, out valB))
            {
                MessageBox.Show("Valor inválido!");
                //txtBx2.Focus();
            }
        }

        private void TxtbxC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxC.Text, out valC))
            {
                MessageBox.Show("Valor inválido!");
                //txtBx2.Focus();
            }
        }

        private void TxtbxTipo_Validated(object sender, EventArgs e)
        {

        }

        private void CalcTriangulo_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtbxA.Text, out valA)) &&
                (double.TryParse(txtbxB.Text, out valB)) && 
                (double.TryParse(txtbxC.Text, out valC)))
            {
                if (valA == valB && valA == valC)
                {
                    //resultado = valC; equilatero
                    txtbxTipo.Text = resultado.ToString();
                }
                else if (valB == valA || valB == valC)
                {
                    //resultado = valB; isóceles
                    txtbxTipo.Text = resultado.ToString();
                }
                else // if (valA != valB && valA != valC){...}
                {
                    //resultado = valA; escaleno
                    txtbxTipo.Text = resultado.ToString();
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!");
            }
        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            txtbxA.Text = "";
            txtbxB.Text = "";
            txtbxC.Text = "";
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
