﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482221013
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }

        private void FrmSobre_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Este trabalho foi criado pela turma da manhã de ADS da FATEC Sorocaba.\n" +
            "\nOs alunos que trabalharam para que este trabalho fosse possível foram:\n" +
            "\nAfonso;" + "\nArthur;" + "\nRute.\n" + "\nCom base na orientação da professora Denilce " +
            "da matéria de Linguagem de Programação II.\n" + "\nLamentamos muito pelo fim do semestre.");
        }
    }
}
