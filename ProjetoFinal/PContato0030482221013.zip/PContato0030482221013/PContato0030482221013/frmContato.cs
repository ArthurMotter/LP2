﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482221013
{
    public partial class frmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();
        public frmContato()
        {
            InitializeComponent();
        }

        private void FrmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtIDContato.DataBindings.Add("TEXT", bnContato, "id_Contato");
                txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_Contato");
                txtEndContato.DataBindings.Add("TEXT", bnContato, "end_Contato");
                txtTelefone.DataBindings.Add("TEXT", bnContato, "cel_Contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_Contato");
                dtpDtCadastroContato.DataBindings.Add("TEXT", bnContato, "dtCadastro_Contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];

                cbxCidade.DisplayMember = "nome_cidade";

                cbxCidade.ValueMember = "id_cidade";

                cbxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }

            bnContato.AddNew();

            txtNomeContato.Enabled = true;
            txtEndContato.Enabled = true;
            cbxCidade.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            txtTelefone.Enabled = true;
            txtEmail.Enabled = true;
            dtpDtCadastroContato.Enabled = true;

            btnNovo.Enabled = true;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNomeContato.Text == "" || txtNomeContato.Text.Length > 50)
            {
                MessageBox.Show("Nome de contato inválido!");
            }
            else if (txtEmail.Text == "" || txtEmail.Text.Length > 100)
            {
                MessageBox.Show("E-mail inválido!", "DADO INVÁLIDO");
            }
            else if (txtEndContato.Text == "" || txtEndContato.Text.Length > 100)
            {
               MessageBox.Show("Endereço inválido!", "DADO INVÁLIDO");
            }
            else if (txtTelefone.Text == "" || txtTelefone.Text.Length > 15)
            {
                MessageBox.Show("Telefone inválido!", "DADO INVÁLIDO");
            }
            else
            {
                Contato RegCon = new Contato();

                RegCon.Idcontato = Convert.ToInt32(txtIDContato.Text);
                RegCon.Nomecontato = txtNomeContato.Text;
                RegCon.Endcontato = txtEndContato.Text;
                RegCon.Emailcontato = txtEmail.Text;
                RegCon.Celcontato = txtTelefone.Text;
                RegCon.Dtcadastrocontato = Convert.ToDateTime(dtpDtCadastroContato.Text);
                RegCon.Cidadeidcidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());

                if (bInclusao)
                {
                    if (RegCon.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso!", "SUCESSO");

                        txtNomeContato.Enabled = false;
                        txtEndContato.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtTelefone.Enabled = false;
                        txtEmail.Enabled = false;
                        dtpDtCadastroContato.Enabled = false;

                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        dsCidade.Tables.Clear();
                        dsCidade.Tables.Add(RegCon.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato!", "ERRO");
                    }
                }
                else
                {
                    if (RegCon.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");
                        dsCidade.Tables.Clear();
                        dsCidade.Tables.Add(RegCon.Listar());

                        txtNomeContato.Enabled = false;
                        txtEndContato.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtTelefone.Enabled = false;
                        txtEmail.Enabled = false;
                        dtpDtCadastroContato.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar contato!");
                    }
                }
            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            txtNomeContato.Enabled = true;
            cbxCidade.Enabled = true;
            txtEndContato.Enabled = true;
            txtTelefone.Enabled = true;
            txtEmail.Enabled = true;
            dtpDtCadastroContato.Enabled = true;
            txtNomeContato.Focus();


            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Contato RegCon = new Contato();
                RegCon.Idcontato = Convert.ToInt16(txtIDContato.Text);

                if (RegCon.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluída com sucesso!");
                    Contato R = new Contato();
                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(R.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();

            txtNomeContato.Enabled = false;
            txtEndContato.Enabled = false;
            cbxCidade.Enabled = false;
            cbxCidade.SelectedIndex = 0;
            txtTelefone.Enabled = false;
            txtEmail.Enabled = false;
            dtpDtCadastroContato.Enabled = false;

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
