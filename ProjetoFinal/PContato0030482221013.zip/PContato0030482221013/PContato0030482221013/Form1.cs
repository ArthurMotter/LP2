﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482221013
{
    public partial class Form1 : Form
    {
        public static SqlConnection conexao;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Data Source = APOLO; Initial Catalog = LP2; User ID = BD2221013

            try
            {
                //conexão da máquina
                conexao = new SqlConnection("Data Source = APOLO; Initial Catalog = LP2; User ID = BD2221013; PASSWORD = Rth$0915");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro no banco de dados!"
                    + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros erros..."
                    + ex.Message);
            }
        }

        private void CidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                frmCidade cidade = new frmCidade();
                cidade.Show();

                MessageBox.Show("O formulário já existe!");
                Application.OpenForms["frmcidade"].BringToFront();
            }
            else
            {
                frmCidade Objc = new frmCidade();
                Objc.MdiParent = this;
                Objc.WindowState = FormWindowState.Maximized;
                Objc.Show();
            }
        }

        private void ContatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                frmContato contato = new frmContato();
                contato.Show();

                MessageBox.Show("O formulário já existe!");
                Application.OpenForms["frmcontato"].BringToFront();
            }
            else
            {
                frmContato Objc = new frmContato();
                Objc.MdiParent = this;
                Objc.WindowState = FormWindowState.Maximized;
                Objc.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobre sobre = new frmSobre();
            sobre.Show();   
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
